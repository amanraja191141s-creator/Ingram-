# v98.63.9.11 — Calculator display and converter picker correction

- Expanded the calculator expression/preview/result display to the marked upper workspace (46% of the calculator viewport on regular portrait screens).
- Rebalanced the five-row keypad to consume the remaining space without overlap; responsive compact and landscape fallbacks retained.
- Preserved horizontal expression scrolling so long expressions do not wrap or force keypad movement.
- Currency and unit selectors now show only the selected item until a deliberate search of at least two characters; search results are capped at eight rows.
- Mirrored authoritative assets into `www/` for Android WebView consistency.
