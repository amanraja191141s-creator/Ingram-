import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const css=fs.readFileSync('assets/css/app.css','utf8');
const js=fs.readFileSync('assets/js/app.js','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const workflow=fs.readFileSync('.github/workflows/main.yml','utf8');
const sw=fs.readFileSync('service-worker.js','utf8');

test('v98.63.9.23 tool cards enforce horizontal readable labels in a responsive 3-column grid',()=>{
  assert.match(css,/#screen-tools \.tools-reference-grid > \.premium-tool-card \{[\s\S]*?flex-direction:column!important/);
  assert.match(css,/#screen-tools \.tools-reference-grid > \.premium-tool-card > \.premium-tool-name \{[\s\S]*?writing-mode:horizontal-tb!important/);
  assert.match(css,/#screen-tools \.tools-reference-grid > \.premium-tool-card > \.premium-tool-name \{[\s\S]*?overflow-wrap:normal!important/);
  assert.match(css,/#screen-tools\.premium-tools-screen\.active[\s\S]*?overflow-y:auto!important/);
  const groups=html.match(/class="tools-reference-section"[\s\S]*?<\/div><\/div>/g)||[];
  const ids=[...html.matchAll(/data-tool-screen="([^"]+)"/g)].map(m=>m[1]);
  assert.equal(ids.length,16); assert.equal(new Set(ids).size,16);
  for (const id of ids) assert.ok(html.includes(`id="screen-${id}"`), `missing destination screen-${id}`);
  assert.match(js,/toolsGrid\?\.addEventListener\('click'/);
  assert.equal((html.match(/class="tools-reference-section"/g)||[]).length,4);
});

test('scientific overlay is wide enough for legible 4x4 controls and larger touch targets',()=>{
  assert.match(css,/#screen-calc #screen-scientific\.scientific-drawer \{[\s\S]*?width:min\(94vw,680px\)!important/);
  assert.match(css,/#screen-calc #screen-scientific \.scientific-function-grid > button \{[\s\S]*?min-height:48px!important/);
  assert.match(css,/#screen-calc #screen-scientific \.scientific-function-grid \{[\s\S]*?repeat\(4,minmax\(0,1fr\)\)!important/);
  const grid=html.match(/<div class="scientific-function-grid"[\s\S]*?<\/div>/)?.[0]||'';
  assert.equal((grid.match(/<button\b/g)||[]).length,16);
  assert.match(js,/insertScientificIntoMain\(token\)/);
});

test('cache, PWA, app and Android workflow use one fresh v98.63.9.23 release identity',()=>{
  assert.equal(pkg.version,'1.98.71-v98.63.9.23');
  assert.match(html,/1\.98\.71-v98\.63\.9\.23/);
  assert.match(js,/APP_VERSION = '1\.98\.71-v98\.63\.9\.23'/);
  assert.match(sw,/v9863923-tools-scientific-actions/);
  assert.match(workflow,/SA_EXPECTED_VERSION: '1\.98\.71-v98\.63\.9\.23'/);
  assert.match(workflow,/versionCode='1098071'/);
  assert.match(workflow,/v9863923-tools-scientific-actions/);
});


test('scientific angle mode initializes from saved preference and exposes accessible state',()=>{
  assert.match(js,/initialAngleButton\.textContent = sci\.angle\.toUpperCase\(\)/);
  assert.match(js,/initialAngleButton\.setAttribute\('aria-pressed', String\(sci\.angle === 'rad'\)\)/);
  assert.match(js,/angleButton\.setAttribute\('aria-pressed', String\(sci\.angle === 'rad'\)\)/);
  assert.match(js,/Angle mode \$\{sci\.angle\.toUpperCase\(\)\}; toggle degrees or radians/);
});

test('scientific controls retain 48px touch targets on short screens and expose keyboard focus',()=>{
  assert.match(css,/@media\(max-height:620px\) \{[\s\S]*?scientific-function-grid > button \{ min-height:48px!important/);
  assert.match(css,/@media\(max-height:620px\) \{[\s\S]*?scientific-more-functions > button \{ min-height:48px!important/);
  assert.match(css,/#screen-tools \.tools-reference-grid > \.premium-tool-card:focus-visible/);
  assert.match(css,/#screen-calc #screen-scientific \.scientific-function-grid > button:focus-visible/);
});
