import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const css = fs.readFileSync(path.join(root, "assets/css/app.css"), "utf8");
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
const js = fs.readFileSync(path.join(root, "assets/js/app.js"), "utf8");
test("v98.35 tool screens fully remove the global header footprint", () => {
  assert.match(css, /body\.tool-screen-active > #app-container > header\.app-header \{[\s\S]*?height:0 !important/);
  assert.match(css, /#screen-viewport > \.screen:not\(#screen-calc\) > \.reference-screen-toolbar \{[\s\S]*?background:#091d35 !important/);
});
test("v98.35 Sales Tax suffix wrapper is borderless while the amount field retains one border", () => {
  assert.match(css, /#screen-salestax \.reference-input-suffix \{[\s\S]*?border:0 !important/);
  assert.match(css, /#screen-salestax \.reference-input-suffix \.input-val-box \{[\s\S]*?border:1px solid/);
});
test("v98.35 quick guide content scrolls independently from its persistent footer", () => {
  assert.match(css, /\.support-modal-content \{[\s\S]*?overscroll-behavior:contain !important/);
  assert.match(css, /\.support-modal-footer \{[\s\S]*?flex:0 0 auto !important/);
  assert.match(html, /id="help-modal"[\s\S]*?class="support-modal-content"[\s\S]*?class="support-modal-footer"/);
});
test("v98.51 tool navigation restores each screen scroll position on return", () => {
  assert.match(js, /screenScrollPositions: Object\.create\(null\)/);
  assert.match(js, /outgoingScroll\.scrollTop/);
  assert.match(js, /scrollContainer\.scrollTop = Math\.max/);
});
